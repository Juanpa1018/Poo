package controlador;

import modelo.Cliente;

import java.util.ArrayList;
import java.util.List;

public class ControladorCliente {

    private List<Cliente> clientes;

    public ControladorCliente(){
        clientes = new ArrayList<>();
    }

    public boolean agregarCliente(Cliente cliente){
        try{
            for(Cliente objCliente : clientes)
                if(objCliente.getCedula().equals(cliente.getCedula())) {
                    System.err.println("ERROR: Ya existe un usuario con la cedula ingresada.");
                    return false;
                }
            clientes.add(cliente);
            return true;
        }catch (Exception e){
            System.out.println("ERROR: No se pudo agregar el cliente, error: " + e.getMessage());
            return false;
        }
    }

    public Cliente buscarCliente(String cedula){
        for(Cliente cliente: clientes){
            if(cliente.getCedula().equals(cedula))
                return cliente;
        }
        return null;
    }

    public List<Cliente> obtenerClientes(){
        return clientes;
    }

    public boolean actualizarCliente(Cliente cliente){
        try {
            for(Cliente cliente1 : clientes) {
                if (cliente1.getCedula().equals(cliente.getCedula())){
                    cliente1.setNombre(cliente.getNombre());
                    cliente1.setFiabilidadDePago(cliente.getFiabilidadDePago());
                    return true;
                }
            }
            return false;
        }catch (Exception e){
            System.err.println("ERROR: No se pudo actualizar el cliente, error: " + e.getMessage());
            return false;
        }
    }

    public boolean borrarCliente(String cedula){
        try{
            int indexCliente = -1;
            for (int i = 0; i < clientes.size(); i++) {
                if(clientes.get(i).getCedula().equals(cedula)) {
                    indexCliente = i;
                    break;
                }
            }
            if(indexCliente != -1)
                clientes.remove(indexCliente);
            else
                System.out.println("ERROR: No se pudo eliminar el cliente, no existe la cedula.");
        }catch (Exception e){
            System.err.println("ERROR: No se pudo eliminar el cliente, error: " + e.getMessage());
        }
        return false;
    }


}
