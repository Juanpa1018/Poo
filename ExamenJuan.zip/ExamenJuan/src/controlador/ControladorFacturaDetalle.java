package controlador;

import modelo.FacturaCabecera;
import modelo.FacturaDetalle;
import modelo.Producto;

import java.util.List;


public class ControladorFacturaDetalle {

    public FacturaDetalle crearFacturaDetalle(int id, FacturaCabecera facturaCabecera, Producto producto,
                                              int cantidad){
        return new FacturaDetalle(id, facturaCabecera, producto, cantidad, this.calcularTotal(producto, cantidad));
    }

    private double calcularTotal(Producto producto, int cantidad){
        return producto.getPrecioUnitario()*cantidad;
    }

    public boolean eliminarFacturaDetalle(List<FacturaDetalle> facturaDetalleList, FacturaDetalle facturaDetalle){
        int indexFacturaDetalle = -1;
        for (int i = 0; i < facturaDetalleList.size(); i++) {
            if(facturaDetalleList.get(i).getId() == facturaDetalle.getId()) {
                indexFacturaDetalle = i;
                break;
            }
        }
        if(indexFacturaDetalle != -1) {
            facturaDetalleList.remove(indexFacturaDetalle);
            return true;
        }else
            return false;
    }
}
