package vista;

import controlador.ControladorCliente;
import controlador.ControladorFacturaCabecera;
import controlador.ControladorFacturaDetalle;
import controlador.ControladorProducto;
import modelo.Cliente;
import modelo.FacturaCabecera;
import modelo.FacturaDetalle;
import modelo.Producto;

import java.util.Date;

public class Main {
    private static ControladorCliente controladorCliente;
    private static ControladorProducto controladorProducto;
    private static ControladorFacturaCabecera controladorFacturaCabecera;
    private static ControladorFacturaDetalle controladorFacturaDetalle;

    public static void main(String[] args) {
        controladorCliente = new ControladorCliente();
        controladorProducto = new ControladorProducto();
        controladorFacturaCabecera = new ControladorFacturaCabecera();
        controladorFacturaDetalle = new ControladorFacturaDetalle();

        // Crea un nuevo cliente
        controladorCliente.agregarCliente(new Cliente("0105652747", "Leo Alvarado", 100));

        // Crear nuevos productos
        controladorProducto.agregarProducto(new Producto(1, "Monitor LG", 120.99, 5, true));
        controladorProducto.agregarProducto(new Producto(2, "Monitor Sony", 199.99, 10, true));
        controladorProducto.agregarProducto(new Producto(3, "Parlantes JBL",    99.99, 2, false));

        // Crea una nueva factura cabecera
        Cliente cliente = controladorCliente.buscarCliente("0105652747");
        controladorFacturaCabecera.agregarFacturaCabecera(new FacturaCabecera(1, cliente, 0, new Date()));

        // Crea nuevas facturas detalles y asigna a las cabeceras
        FacturaCabecera facturaCabecera = controladorFacturaCabecera.buscarFacturaCabecera(1);
        FacturaDetalle facturaDetalle = controladorFacturaDetalle.crearFacturaDetalle(1, facturaCabecera,
                controladorProducto.buscarProducto(1), 2);
        controladorFacturaCabecera.agregarFacturaDetalle(facturaCabecera, facturaDetalle);

        facturaDetalle = controladorFacturaDetalle.crearFacturaDetalle(2, facturaCabecera,
                controladorProducto.buscarProducto(2), 5);
        controladorFacturaCabecera.agregarFacturaDetalle(facturaCabecera, facturaDetalle);

        facturaDetalle = controladorFacturaDetalle.crearFacturaDetalle(3, facturaCabecera,
                controladorProducto.buscarProducto(3), 1);
        controladorFacturaCabecera.agregarFacturaDetalle(facturaCabecera, facturaDetalle);

        System.out.println(controladorFacturaCabecera.obtenerFacturasCabeceras());

    }
}
