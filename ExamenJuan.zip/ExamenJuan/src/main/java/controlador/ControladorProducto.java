package controlador;

import modelo.Producto;

import java.util.ArrayList;
import java.util.List;

public class ControladorProducto {

    private List<Producto> productos;

    public ControladorProducto(){
        productos = new ArrayList<>();
    }

    public boolean agregarProducto(Producto producto){
        try{
            for(Producto objProducto : productos)
                if(objProducto.getId()== producto.getId()) {
                    System.err.println("ERROR: Ya existe un producto con el id ingresado.");
                    return false;
                }
            productos.add(producto);
            return true;
        }catch (Exception e){
            System.out.println("ERROR: No se pudo agregar el producto, error: " + e.getMessage());
            return false;
        }
    }

    public Producto buscarProducto(int id){
        for(Producto producto: productos){
            if(producto.getId() == id)
                return producto;
        }
        return null;
    }

    public List<Producto> obtenerProductos(){
        return productos;
    }

    public boolean actualizarProducto(Producto producto){
        try {
            for(Producto producto1 : productos) {
                if (producto1.getId() == producto.getId()){
                    producto1.setDescripcion(producto.getDescripcion());
                    producto1.setLlevaIva(producto.isLlevaIva());
                    producto1.setStock(producto.getStock());
                    producto1.setPrecioUnitario(producto.getPrecioUnitario());
                    return true;
                }
            }
            return false;
        }catch (Exception e){
            System.err.println("ERROR: No se pudo actualizar el producto, error: " + e.getMessage());
            return false;
        }
    }

    public boolean borrarProducto(int id){
        try{
            int indexProducto = -1;
            for (int i = 0; i < productos.size(); i++) {
                if(productos.get(i).getId()== id) {
                    indexProducto = i;
                    break;
                }
            }
            if(indexProducto != -1)
                productos.remove(indexProducto);
            else
                System.out.println("ERROR: No se pudo eliminar el producto, no existe el ID.");
        }catch (Exception e){
            System.err.println("ERROR: No se pudo eliminar el producto, error: " + e.getMessage());
        }
        return false;
    }

    public boolean reducirStock(int id, int cantidadVendida){
        for(Producto producto : productos)
            if(producto.getId() == id) {
                producto.setStock(producto.getStock() - cantidadVendida);
                return true;
            }
        return false;
    }

    public Producto buscarProducto(String nombre) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}
