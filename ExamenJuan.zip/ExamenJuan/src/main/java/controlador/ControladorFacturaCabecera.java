package controlador;

import modelo.Cliente;
import modelo.FacturaCabecera;
import modelo.FacturaDetalle;
import modelo.Producto;

import java.util.ArrayList;
import java.util.List;

public class ControladorFacturaCabecera {

    private ControladorFacturaDetalle controladorFacturaDetalle;
    private List<FacturaCabecera> facturaCabeceras;

    public ControladorFacturaCabecera(){
        facturaCabeceras = new ArrayList<>();
    }

    public boolean agregarFacturaCabecera(FacturaCabecera facturaCabecera){
        facturaCabecera.setTotal(this.calcularTotal(facturaCabecera.getFacturaDetalles()));
        return facturaCabeceras.add(facturaCabecera);
    }

    public boolean agregarFacturaDetalle(FacturaCabecera facturaCabecera, FacturaDetalle facturaDetalle){
        for(FacturaCabecera facturaCabecera1 : facturaCabeceras){
            if(facturaCabecera1.getId() == facturaCabecera.getId()) {
                facturaCabecera1.getFacturaDetalles().add(facturaDetalle);
                facturaCabecera1.setTotal(calcularTotal(facturaCabecera1.getFacturaDetalles()));
                return true;
            }
        }
        return false;
    }

    public FacturaCabecera buscarFacturaCabecera(int id){
        for(FacturaCabecera facturaCabecera : facturaCabeceras)
            if(facturaCabecera.getId() == id)
                return facturaCabecera;
        return null;
    }

    public List<FacturaCabecera> obtenerFacturasCabeceras(){
        return facturaCabeceras;
    }

    public boolean actualizarFacturaCabecera(FacturaCabecera facturaCabecera){
        for(FacturaCabecera facturaCabecera1 : facturaCabeceras) {
            if (facturaCabecera1.getId() == facturaCabecera.getId()){
                facturaCabecera1.setCliente(facturaCabecera.getCliente());
                facturaCabecera1.setFecha(facturaCabecera.getFecha());
                facturaCabecera1.setFacturaDetalles(facturaCabecera.getFacturaDetalles());
                facturaCabecera1.setTotal(facturaCabecera.getTotal());
                return true;
            }
        }
        return false;
    }

    public boolean borrarFacturaCabecera(FacturaCabecera facturaCabecera){
        for(FacturaCabecera facturaCabecera1 : facturaCabeceras){
            if(facturaCabecera1.getId() == facturaCabecera.getId()) {
                facturaCabecera1.borrarFactura();
                return facturaCabecera1.isEstaBorrada();
            }
        }
        return false;
    }

    private double calcularTotal(List<FacturaDetalle> facturaDetalles){
        double total = 0;
        for(FacturaDetalle facturaDetalle : facturaDetalles){
            total += facturaDetalle.getValorTotal();
        }
        return total;
    }

    public FacturaCabecera buscarFacturaCabecera(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Iterable<FacturaCabecera> obtenerFacturaCabecera() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
