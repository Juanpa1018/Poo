package modelo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FacturaCabecera {

    private int id;
    private Cliente cliente;
    private double total;
    private Date fecha;
    private boolean estaBorrada;
    private List<FacturaDetalle> facturaDetalles;

    public FacturaCabecera(){
        fecha = new Date();
        facturaDetalles = new ArrayList<>();
    }

    public FacturaCabecera(int id, Cliente cliente, double total, Date fecha) {
        fecha = new Date();
        facturaDetalles = new ArrayList<>();
        this.id = id;
        this.cliente = cliente;
        this.total = total;
        this.fecha = fecha;
    }

    public FacturaCabecera(String id, String cliente, String total, String fecha) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public boolean isEstaBorrada() {
        return estaBorrada;
    }

    public List<FacturaDetalle> getFacturaDetalles() {
        return facturaDetalles;
    }

    public void setFacturaDetalles(List<FacturaDetalle> facturaDetalles) {
        this.facturaDetalles = facturaDetalles;
    }

    public void borrarFactura(){
        this.estaBorrada = true;
    }

    @Override
    public String toString() {
        return "FacturaCabecera{" +
                "id=" + id +
                ", cliente=" + cliente +
                ", total=" + total +
                ", fecha=" + fecha +
                ", estaBorrada=" + estaBorrada +
                ", facturaDetalles=" + facturaDetalles +
                '}';
    }
}
