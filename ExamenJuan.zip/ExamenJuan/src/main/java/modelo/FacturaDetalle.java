package modelo;

public class FacturaDetalle {

    private int id;
    private FacturaCabecera facturaCabecera;
    private Producto producto;
    private int cantidad;
    private double valorTotal;

    public FacturaDetalle(){

    }

    public FacturaDetalle(int id, FacturaCabecera facturaCabecera, Producto producto, int cantidad, double valorTotal) {
        this.id = id;
        this.facturaCabecera = facturaCabecera;
        this.producto = producto;
        this.cantidad = cantidad;
        this.valorTotal = valorTotal;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public FacturaCabecera getFacturaCabecera() {
        return facturaCabecera;
    }

    public void setFacturaCabecera(FacturaCabecera facturaCabecera) {
        this.facturaCabecera = facturaCabecera;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    @Override
    public String toString() {
        return "FacturaDetalle{" +
                "id=" + id +
                ", producto=" + producto +
                ", cantidad=" + cantidad +
                ", valorTotal=" + valorTotal +
                '}';
    }
}
