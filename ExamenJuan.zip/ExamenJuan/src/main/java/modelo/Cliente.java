package modelo;

import java.util.Objects;

public class Cliente {

    // Atributos del cliente
    private String nombre;
    private String cedula;
    private int fiabilidadDePago;

    // Constructor por defecto
    public Cliente(){

    }

    // Constructor con atributos.
    public Cliente(String cedula, String nombre, int fiabilidadDePago){
        this.nombre = nombre;
        this.cedula = cedula;
        this.fiabilidadDePago = fiabilidadDePago;
    }


    // Getters y setters.
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public int getFiabilidadDePago() {
        return fiabilidadDePago;
    }

    public void setFiabilidadDePago(int fiabilidadDePago) {
        this.fiabilidadDePago = fiabilidadDePago;
    }

    // Metodo toString
    @Override
    public String toString() {
        return "Cliente{" +
                "nombre='" + nombre + '\'' +
                ", cedula='" + cedula + '\'' +
                ", fiabilidadDePago=" + fiabilidadDePago +
                '}';
    }

}
