package vista;

import controlador.ControladorCliente;
import modelo.Cliente;

import java.util.Scanner;

public class VistaCliente {

    private Scanner scanner;
    private ControladorCliente controladorCliente;

    public VistaCliente(){
        scanner = new Scanner(System.in);
        controladorCliente = new ControladorCliente();
        generarMenu();
    }

    private void generarMenu(){

        int opcionSeleccionada = -1;

        while(opcionSeleccionada != 0){

            System.out.println("Seleccione la accion que desea realizar:" +
                    "\n0. Menu principal" +
                    "\n1. Crear un nuevo cliente" +
                    "\n2. Buscar cliente" +
                    "\n3. Obtener clientes" +
                    "\n4. Actualizar cliente" +
                    "\n5. Borrar cliente");
            opcionSeleccionada = Integer.parseInt(scanner.nextLine());
            switch (opcionSeleccionada){
                case 1:
                    crearUsuario();
                    break;
                case 2:
                    buscarCliente();
                    break;
                case 3:
                    obtenerClientes();
                    break;
                case 4:
                    actualizarClientes();
                    break;
                case 5:
                    borrarClientes();
                    break;
                default:
                    break;
            }
        }
    }

    private void crearUsuario(){
        System.out.println("Ingrese los datos usuario, cedula, nombre, fiabilidad de pago, separadas por un enter:");

        System.out.print("Cedula: ");
        String cedula = scanner.nextLine();

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Fiabilidad de pago: ");
        int fiabilidadDePago = Integer.parseInt(scanner.nextLine());

        controladorCliente.agregarCliente(new Cliente(cedula, nombre, fiabilidadDePago));
    }

    private void buscarCliente(){
        Cliente cliente;
        System.out.print("Ingrese la cedula del cliente: ");
        String cedula = scanner.nextLine();

        cliente = controladorCliente.buscarCliente(cedula);
        System.out.println("Cliente encontrado: " + cliente);
    }

    private void obtenerClientes(){
        System.out.println("Clientes registrados: ");
        for(Cliente cliente : controladorCliente.obtenerClientes())
            System.out.println(cliente.toString());
    }

    private void actualizarClientes(){
        System.out.println("Ingrese los nuevos datos del usario con su cedula antigua, nombre nuevo, separados por un enter:");

        System.out.print("Cedula (original): ");
        String cedulaAnterior = scanner.nextLine();

        System.out.println("Nombre (nuevo): ");
        String nombre = scanner.nextLine();

        System.out.println("Fiablidad de pago (nuevo): ");
        int fiabilidadDePago = Integer.parseInt(scanner.nextLine());

        controladorCliente.actualizarCliente(new Cliente(cedulaAnterior, nombre, fiabilidadDePago));
    }

    private void borrarClientes(){

        System.out.print("Ingrese la cedula del cliente: ");
        String cedula = scanner.nextLine();

        controladorCliente.borrarCliente(cedula);

    }
}
