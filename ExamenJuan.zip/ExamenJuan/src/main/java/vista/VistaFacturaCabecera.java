/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import controlador.ControladorFacturaCabecera;
import java.util.List;

import java.util.Scanner;
import modelo.FacturaCabecera;
import modelo.FacturaDetalle;
/**
 *
 * @author pabli
 */
public class VistaFacturaCabecera {

    private Scanner scanner;
    private ControladorFacturaCabecera controladorFacturaCabecera;

    public VistaFacturaCabecera(){
        scanner = new Scanner(System.in);
        controladorFacturaCabecera = new ControladorFacturaCabecera();
        generarMenu();
    }   

  private void generarMenu(){

        int opcionSeleccionada = -1;

        while(opcionSeleccionada != 0){

            System.out.println("Seleccione la accion que desea realizar:" +
                    "\n0. Menu principal" +
                    "\n1. Crear una facturacabecera" +
                    "\n2. Buscar facturacabecera" +
                    "\n3. Obtener facturacabecera" +
                    "\n4. Actualizar facturacabecera" +
                    "\n5. Borrar facturacabecera"+
                    "\n6. calcular total"); 
opcionSeleccionada = Integer.parseInt(scanner.nextLine());
            switch (opcionSeleccionada){
                case 1:
                    crearFacturaCabecera();
                    break;
                case 2:
                    buscarFacturaCabecera();
                    break;
                case 3:
                    obtenerFacturaCabecera();
                    break;
                case 4:
                    actualizarFacturaCabecera();
                    break;
                case 5:
                    borrarFacturaCabecera();
                    break;
                 case 6:
                    calcularTotal();
                    break;
                default:
                    break;
            }
        }
    }

    private void crearFacturaCabecera(){
        System.out.println("Ingrese los datos de la factura cabecera, id, cliente, total, fecha, separadas por un enter:");

        System.out.print("Id: ");
        String id = scanner.nextLine();

        System.out.print("Cliente: ");
        String cliente = scanner.nextLine();
        
        System.out.print("Total: ");
        String total = scanner.nextLine();
        
        System.out.print("fecha: ");
        String fecha = scanner.nextLine();

        controladorFacturaCabecera .agregarFacturaCabecera(new FacturaCabecera( id, cliente, total, fecha));
    }
    private void buscarFacturaCabecera(){
        FacturaCabecera facturacabecera;
        System.out.print("Ingrese el Id de la factura: ");
        String id = scanner.nextLine();

        facturacabecera = controladorFacturaCabecera.buscarFacturaCabecera(id);
        System.out.println("Factura Cabecera  encontrado: " + facturacabecera);
    }

    private void obtenerFacturaCabecera(){
        System.out.println("Facturas Cabeceras registradas: ");
        for(FacturaCabecera facturacabecera : controladorFacturaCabecera.obtenerFacturaCabecera())
            System.out.println(facturacabecera.toString());
    }
    private void actualizarFacturaCabecera(){ 
        System.out.println("Ingrese los nuevos datos de la factura cabecera con su id antigua, separados por un enter:");

        System.out.print("Id (original): ");
        String id = scanner.nextLine();

        System.out.println("Id (nueva): ");
        String id = scanner.nextLine();

        System.out.println("Cedula (nueva): ");
        int cedula = Integer.parseInt(scanner.nextLine());

        controladorFacturaCabecera.actualizarFacturaCabecera(new FacturaCabecera(idAnterior, idNueva, cedula));
    }

    private void borrarFacturaCabecera(){

        System.out.print("Ingrese el nombre de la FacturaCabecera: ");
        String nombre = scanner.nextLine();

        controladorFacturaCabecera.borrarFacturaCabecera(nombre);

    }
    private void calcularTotal(){

        System.out.print("Calculo Total: ");
        int calculartotal = Integer.parseInt (scanner.nextLine());

        controladorFacturaCabecera.calculartotalFacturaCabecera (new CalcularTotal( List<FacturaDetalle> facturaDetalles));
    }
}