/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;
 
import controlador.ControladorProducto;
import modelo.Producto;

import java.util.Scanner;
/**
 *
 * @author pabli
 */
public class VistaProducto {
    private Scanner scanner;
    private ControladorProducto controladorProducto;

    public VistaProducto(){
        scanner = new Scanner(System.in);
        controladorProducto = new ControladorProducto();
        generarMenu();
    }
     private void generarMenu(){

        int opcionSeleccionada = -1;

        while(opcionSeleccionada != 0){

            System.out.println("Seleccione la accion que desea realizar:" +
                    "\n0. Menu principal" +
                    "\n1. Agregar un producto " +
                    "\n2. Buscar producto" +
                    "\n3. Obtener productos" +
                    "\n4. Actualizar producto" +
                    "\n5. Borrar producto");
                    "\n6. Reducir Stock");
            opcionSeleccionada = Integer.parseInt(scanner.nextLine());
            switch (opcionSeleccionada){
                case 1:
                    agregarProducto();
                    break;
                case 2:
                    buscarProducto();
                    break;
                case 3:
                    obtenerProductos();
                    break;
                case 4:
                    actualizarProducto();
                    break;
                case 5:
                    borrarProductos();
                    break;
                case 6:
                    reducirStock();
                    break;  
                default:
                    break;
            }
        }
    }
     private void agregarProducto(){
        System.out.println("Ingrese los datos del producto, id, descripcion, preciounitario, stock, iva, separadas por un enter:");

        System.out.print("Id:");
        String id = scanner.nextLine();

        System.out.print("Descripcion: ");
        String descripcion = scanner.nextLine();
        
        System.out.print("Presiounitario: ");
        String preciounitario = scanner.nextLine();
        
        System.out.print(" Stock: ");
        String stock = scanner.nextLine();

        System.out.print("Iva ");
        int iva = Integer.parseInt(scanner.nextLine());

        controladorProducto.agregarProducto (new Producto ( id, descripcion, preciounitario, stock, iva));
    }

    private void buscarProducto(){
        Producto producto;
        System.out.print("Ingrese el nombre del producto: ");
        String nombre = scanner.nextLine();

        producto = controladorProducto.buscarProducto(nombre);
        System.out.println("Producto encontrado: " + producto);
    }

    private void obtenerProductos(){
        System.out.println("Productos registrados: ");
        for(Producto producto : controladorProducto.obtenerProductos())
            System.out.println(producto.toString());
    }

    private void actualizarProducto(){
        System.out.println("Ingrese los nuevos productos  con su id antigua, id nueva, separados por un enter:");

        System.out.print("Id (original): ");
        String id = scanner.nextLine();

        System.out.println("Id (nuevo): ");
        String id = scanner.nextLine();

        controladorProducto.actualizarProducto(new Producto(idAnterior, idNueva ));
    }

    private void borrarProductos(){

        System.out.print("Ingrese el id del producto: ");
        String id = scanner.nextLine();
        int Id = 0;

        controladorProducto.borrarProducto (Id);

    }
}