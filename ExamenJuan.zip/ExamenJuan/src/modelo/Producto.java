package modelo;

public class Producto {

    private int id;
    private String descripcion;
    private double precioUnitario;
    private int stock;
    private boolean llevaIva;

    public Producto(){}

    public Producto(int id, String descripcion, double precioUnitario, int stock, boolean llevaIva) {
        this.id = id;
        this.descripcion = descripcion;
        this.precioUnitario = precioUnitario;
        this.stock = stock;
        this.llevaIva = llevaIva;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public boolean isLlevaIva() {
        return llevaIva;
    }

    public void setLlevaIva(boolean llevaIva) {
        this.llevaIva = llevaIva;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "id=" + id +
                ", descripcion='" + descripcion + '\'' +
                ", precioUnitario=" + precioUnitario +
                ", stock=" + stock +
                ", iva=" + llevaIva +
                '}';
    }
}
