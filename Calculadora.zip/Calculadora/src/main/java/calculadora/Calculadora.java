/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

/**
 *
 * @author pabli
 */

//fecha del trabajo: 17/06/2021
public class Calculadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        VistaInicio vistaInicio = new VistaInicio();
        vistaInicio.setVisible(true);
    }
    
}