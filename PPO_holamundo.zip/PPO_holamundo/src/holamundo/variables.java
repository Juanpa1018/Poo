/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package holamundo;

/**
 *
 * @author Cristian
 */
public class variables {
    public static void main(String[] args) {
        String x="hola mundo";
        char arreglo[]=x.toCharArray();
        for(int i=arreglo.length-1;i<=0;i--){
            System.out.println(arreglo.length+(i));
    }
    }
}
